
class Footer extends HTMLElement{
    constructor(){
        super();
        this.innerHTML=`<br><hr>
<div class="div_pi">
    <strong>Ubicados: </strong>En el aula....donde mas.<br/>
    <strong>eMail:    </strong> <a href="mailto:jruiz@utn.ac.cr?subject=Solicito información">jruiz@utn.ac.cr</a><br />
    <strong>Teléfono: </strong>85 42 89 18
</div>
<div class="div_pc">
    Carrera de Tecnologías de la información<br/>
    Curso de Tecnologías y Sistemas Web 2<br/>
    Desarrollado completamente a mano con malicia indigena
</div>
<div class="div_pd">
    <a href="https://www.facebook.com/"><i class="fa fa-2x fa-facebook"></i></a>
    <br>
    <a href="https://twitter.com/"><i class="fa fa-2x fa-twitter"></i></a>
</div>` 
    }     
}

customElements.define('footer-component', Footer);