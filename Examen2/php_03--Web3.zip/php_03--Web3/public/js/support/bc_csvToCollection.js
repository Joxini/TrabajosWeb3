// JavaScript Document
var db = firebase.apps[0].firestore();
const txtCSV = document.querySelector('#txtCSV');
const btnLoad = document.querySelector('#btnLoad');
btnLoad.addEventListener('click', function () {
    lecturaCSV(txtCSV.files[0]).then(r => {
        txtCSV.value = '';
    });
});

async function lecturaCSV(archivo) {
    const nomarch = archivo.name.split('.')[0];
    const lector = new FileReader();
    lector.readAsText(archivo);
    await esperarSegundos();
    if (lector.result != null) {
        let data = lector.result.split('\n');
        let etiquetas = data[0].split(';');
        for (let index = 1; index < data.length; index++) {
            const valores = data[index].split(';');
            let salida = {}
            for (let index2 = 0; index2 < etiquetas.length; index2++) {
                salida[etiquetas[index2]] = procesarDato(valores[index2]);
            }
            db.collection(nomarch).add(salida).then(function (docRef) {
                console.log("ID del registro: " + docRef.id);
            }).catch(function (FirebaseError) {
                console.log("Error al registrar el dato: " + FirebaseError);
            });
        }
    }
}

function esperarSegundos() {
    return new Promise((resolve) => {
        setTimeout(() => {
            resolve('resolved');
        }, 5000);
    });
}

function procesarDato(dato) {
    // Verificar si el dato es nulo, en blanco o indefinido
    if (dato === null || dato === '' || dato === undefined) {
        return 'na';
    }

    // Verificar si el dato es una fecha
    const fechaConFormato = new Date(dato);
    if (!isNaN(fechaConFormato.getTime())) {
        return fechaConFormato;
    }

    // Intentar convertir el dato a número (entero o flotante)
    const numero = parseFloat(dato);
    if (!isNaN(numero)) {
        // Verificar si es un número entero
        if (numero % 1 === 0) {
            return parseInt(dato, 10);
        } else {
            return numero;
        }
    }

    // Si no es un número ni una fecha, devolver el dato como cadena
    return dato;
}

